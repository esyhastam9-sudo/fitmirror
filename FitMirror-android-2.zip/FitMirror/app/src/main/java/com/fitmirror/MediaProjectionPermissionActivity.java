package com.fitmirror;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.widget.Toast;

/**
 * Transparent activity that triggers Android's native
 * "Start recording or casting?" system dialog (the screenshot you sent
 * is the app's OWN pre-permission explainer; this is what comes after
 * the user taps "اکنون شروع شود" — the actual OS-level grant).
 *
 * Result is forwarded to ScreenCaptureService which keeps the
 * projection token alive for repeated captures, just like Screen Translate.
 */
public class MediaProjectionPermissionActivity extends Activity {

    private static final int REQ_CODE = 9001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        MediaProjectionManager mgr =
                (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mgr.createScreenCaptureIntent(), REQ_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_CODE) {
            if (resultCode == RESULT_OK && data != null) {
                // Hand the grant to the foreground service that owns the
                // MediaProjection for the rest of this session.
                Intent svc = new Intent(this, ScreenCaptureService.class);
                svc.setAction(ScreenCaptureService.ACTION_START);
                svc.putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode);
                svc.putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data);
                startForegroundService(svc);

                // Now show the floating bubble — capture is armed.
                startService(new Intent(this, FloatingBubbleService.class));
            } else {
                Toast.makeText(this, "بدون اجازه ضبط صفحه، حباب کار نمی‌کند",
                        Toast.LENGTH_LONG).show();
            }
        }
        finish();
    }
}
