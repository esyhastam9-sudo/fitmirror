package com.fitmirror;

import android.os.Handler;
import android.os.Looper;
import org.json.JSONObject;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * ApiClient
 * ─────────
 * Talks to YOUR backend (not Anthropic directly) for anything that decides
 * money or free-credit eligibility. This is the actual fix for the
 * "10 emails = 70 free tries" problem: the client can lie about anything,
 * so the free-credit ledger has to be a server-side table keyed by
 * phone number (and secondarily by device id), never trusted from the app.
 *
 * Suggested backend table:
 *   phone_registry(phone TEXT PRIMARY KEY, device_id TEXT, credits_used INT,
 *                   plan TEXT, plan_expires_at TIMESTAMP)
 *
 * Endpoints this MVP expects (implement with any stack — Node/Express,
 * Supabase Edge Functions, Firebase Functions, etc.):
 *   POST /auth/send-otp     { phone, deviceId }              → { ok: true }
 *   POST /auth/verify-otp   { phone, otp, deviceId, email }  → { credits, plan }
 *   POST /credits/consume   { phone }                        → { credits }
 *   POST /billing/subscribe { phone, planId }                → { plan, expiresAt }
 *
 * ⚠️ Replace BASE_URL with your real backend before shipping.
 */
public class ApiClient {

    private static final String BASE_URL = "https://api.fitmirror.app"; // ← your backend

    public interface Callback {
        void onSuccess(String responseJson);
        void onError(String message);
    }

    public static void sendOtp(String phone, String deviceId, Callback cb) {
        JSONObject body = new JSONObject();
        try {
            body.put("phone", phone);
            body.put("deviceId", deviceId);
        } catch (Exception e) { cb.onError("خطای داخلی"); return; }
        post("/auth/send-otp", body, cb);
    }

    public static void verifyOtp(String phone, String otp, String deviceId, String email, Callback cb) {
        JSONObject body = new JSONObject();
        try {
            body.put("phone", phone);
            body.put("otp", otp);
            body.put("deviceId", deviceId);
            body.put("email", email);
        } catch (Exception e) { cb.onError("خطای داخلی"); return; }
        post("/auth/verify-otp", body, cb);
    }

    /** Call right after a successful try-on, so the server decrements the real counter. */
    public static void consumeCredit(String phone, Callback cb) {
        JSONObject body = new JSONObject();
        try { body.put("phone", phone); } catch (Exception e) { cb.onError("خطای داخلی"); return; }
        post("/credits/consume", body, cb);
    }

    public static void subscribe(String phone, String planId, Callback cb) {
        JSONObject body = new JSONObject();
        try {
            body.put("phone", phone);
            body.put("planId", planId);
        } catch (Exception e) { cb.onError("خطای داخلی"); return; }
        post("/billing/subscribe", body, cb);
    }

    // ── Parsing helpers ──────────────────────────────────────────────────

    public static int parseCredits(String json) {
        try { return new JSONObject(json).optInt("credits", 0); }
        catch (Exception e) { return 0; }
    }

    public static String parsePlan(String json) {
        try {
            String p = new JSONObject(json).optString("plan", null);
            return "null".equals(p) ? null : p;
        } catch (Exception e) { return null; }
    }

    // ── Networking ───────────────────────────────────────────────────────

    private static void post(String path, JSONObject body, Callback cb) {
        new Thread(() -> {
            try {
                URL url = new URL(BASE_URL + path);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);
                conn.setConnectTimeout(15_000);
                conn.setReadTimeout(15_000);

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(body.toString().getBytes("UTF-8"));
                }

                int status = conn.getResponseCode();
                InputStream is = status >= 400 ? conn.getErrorStream() : conn.getInputStream();
                StringBuilder sb = new StringBuilder();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"))) {
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                }

                String responseBody = sb.toString();
                if (status >= 400) {
                    String msg = "خطا در ارتباط با سرور";
                    try { msg = new JSONObject(responseBody).optString("error", msg); } catch (Exception ignored) {}
                    final String finalMsg = msg;
                    post(() -> cb.onError(finalMsg));
                } else {
                    post(() -> cb.onSuccess(responseBody));
                }
            } catch (Exception e) {
                post(() -> cb.onError("اتصال به سرور برقرار نشد"));
            }
        }).start();
    }

    private static void post(Runnable r) {
        new Handler(Looper.getMainLooper()).post(r);
    }
}
