package com.fitmirror;

import android.app.*;
import android.content.Intent;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.os.Handler;
import android.os.Looper;
import android.view.*;
import android.widget.*;
import androidx.core.app.NotificationCompat;

/**
 * FloatingBubbleService
 * ─────────────────────
 * Draws a draggable gold bubble (👗) over ALL other apps.
 * When tapped → opens an image picker so user picks the clothing photo,
 * then launches TryOnActivity with that image.
 *
 * Lifecycle:
 *   MainActivity → startForegroundService(this) → moveTaskToBack()
 *   User browses freely. Bubble stays visible.
 *   User taps bubble → picks clothing image → TryOnActivity opens → service stops.
 */
public class FloatingBubbleService extends Service {

    private static final String CHANNEL_ID   = "fitmirror_overlay";
    private static final int    NOTIF_ID     = 1;
    public  static final int    PICK_IMAGE   = 200;

    private WindowManager windowManager;
    private View          bubbleView;
    private WindowManager.LayoutParams params;

    // Touch drag state
    private int initialX, initialY;
    private float initialTouchX, initialTouchY;
    private long  touchDownMs;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIF_ID, buildNotification());
        showBubble();
    }

    // ── Bubble UI ─────────────────────────────────────────────────────────

    private void showBubble() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        bubbleView = buildBubbleView();

        params = new WindowManager.LayoutParams(
                dpToPx(72), dpToPx(72),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 40;
        params.y = 300;

        windowManager.addView(bubbleView, params);

        bubbleView.setOnTouchListener(this::onBubbleTouch);
    }

    private View buildBubbleView() {
        // Outer circle — gold gradient
        FrameLayout frame = new FrameLayout(this);

        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{0xFFC9A96E, 0xFFA8823F}
        );
        bg.setShape(GradientDrawable.OVAL);
        bg.setStroke(dpToPx(2), 0xFF3A3028);
        frame.setBackground(bg);

        // Elevation shadow effect
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            frame.setElevation(dpToPx(8));
        }

        // Dress emoji label
        TextView tv = new TextView(this);
        tv.setText("👗");
        tv.setTextSize(28);
        tv.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        );
        frame.addView(tv, lp);

        // Pulse ring (simple scale animation hint via alpha)
        frame.setAlpha(0.95f);

        return frame;
    }

    // ── Touch: drag + tap detection ───────────────────────────────────────

    private boolean onBubbleTouch(View v, MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                initialX      = params.x;
                initialY      = params.y;
                initialTouchX = event.getRawX();
                initialTouchY = event.getRawY();
                touchDownMs   = System.currentTimeMillis();
                return true;

            case MotionEvent.ACTION_MOVE:
                params.x = initialX + (int)(event.getRawX() - initialTouchX);
                params.y = initialY + (int)(event.getRawY() - initialTouchY);
                windowManager.updateViewLayout(bubbleView, params);
                return true;

            case MotionEvent.ACTION_UP:
                long elapsed = System.currentTimeMillis() - touchDownMs;
                float dx = Math.abs(event.getRawX() - initialTouchX);
                float dy = Math.abs(event.getRawY() - initialTouchY);
                boolean isTap = elapsed < 300 && dx < 10 && dy < 10;
                if (isTap) onBubbleTapped();
                return true;
        }
        return false;
    }

    private void onBubbleTapped() {
        // Hide the bubble itself for a beat so it doesn't appear in the capture,
        // then ask ScreenCaptureService to grab whatever's on screen right now
        // (gallery photo, Telegram chat, Instagram post, browser — anything).
        bubbleView.setVisibility(View.INVISIBLE);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            Intent capture = new Intent(this, ScreenCaptureService.class);
            capture.setAction(ScreenCaptureService.ACTION_CAPTURE);
            startService(capture);

            // Bring bubble back after the shot is taken
            new Handler(Looper.getMainLooper()).postDelayed(
                    () -> bubbleView.setVisibility(View.VISIBLE), 400);
        }, 150);
    }

    // ── Cleanup ───────────────────────────────────────────────────────────

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (windowManager != null && bubbleView != null) {
            windowManager.removeView(bubbleView);
        }
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    // ── Notification (required for foreground service) ────────────────────

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "FitMirror Overlay", NotificationManager.IMPORTANCE_LOW
            );
            ch.setDescription("حباب پروو لباس");
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private Notification buildNotification() {
        Intent stopIntent = new Intent(this, FloatingBubbleService.class);
        stopIntent.setAction("STOP");
        PendingIntent stopPi = PendingIntent.getService(
                this, 0, stopIntent, PendingIntent.FLAG_IMMUTABLE);

        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPi = PendingIntent.getActivity(
                this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("FitMirror فعاله 👗")
                .setContentText("هرجا لباس دیدی، روی حباب طلایی بزن تا پرو بشه")
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentIntent(openPi)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "بستن", stopPi)
                .setOngoing(true)
                .build();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            stopSelf();
        }
        return START_STICKY;
    }

    // ── Util ──────────────────────────────────────────────────────────────

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}
