package com.fitmirror;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

/**
 * Transparent trampoline activity.
 * The floating bubble can't start an image-picker intent directly
 * (services can't receive Activity results). This invisible activity
 * bridges the gap: it opens the picker, gets the result, then
 * hands the URI to TryOnActivity and closes the bubble service.
 */
public class ImagePickerTrampolineActivity extends Activity {

    private static final int PICK_REQ = 201;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Launch system image picker (gallery, files, anything)
        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
        pick.setType("image/*");
        pick.addCategory(Intent.CATEGORY_OPENABLE);

        // Also allow picking a screenshot just taken
        Intent chooser = Intent.createChooser(pick, "عکس لباس را انتخاب کن");
        startActivityForResult(chooser, PICK_REQ);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_REQ) {
            // Stop the floating bubble
            stopService(new Intent(this, FloatingBubbleService.class));

            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri imageUri = data.getData();

                // Open TryOn with the chosen clothing image
                Intent tryOn = new Intent(this, TryOnActivity.class);
                tryOn.putExtra(TryOnActivity.EXTRA_CLOTH_URI, imageUri.toString());
                tryOn.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(tryOn);
            }

            finish(); // close this transparent activity
        }
    }
}
