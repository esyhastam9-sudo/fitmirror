package com.fitmirror;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class MainActivity extends AppCompatActivity {

    private SharedPreferences prefs;

    // Auth views (step 1: name + email)
    private View authLayout;
    private EditText etName, etEmail;
    private Button btnAuth;
    private TextView tvAuthToggle, tvAuthMode;

    // Phone verify views (step 2: phone + OTP — gate for free credits)
    private View phoneLayout;
    private EditText etPhone, etOtp;
    private Button btnSendOtp, btnVerifyOtp;
    private View otpGroup;

    // Home views
    private View homeLayout;
    private TextView tvWelcome, tvCredits;
    private CardView btnTryOn, btnFloating;

    private boolean isLoginMode = false;

    static final String PREF_EMAIL     = "email";
    static final String PREF_NAME      = "name";
    static final String PREF_PHONE     = "phone";
    static final String PREF_CREDITS   = "credits";
    static final String PREF_PLAN      = "plan";       // null / "monthly"
    static final int    FREE_CREDITS   = 7;
    static final int    OVERLAY_PERM_REQ = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("fitmirror", MODE_PRIVATE);

        bindAuthViews();
        bindPhoneViews();
        bindHomeViews();

        if (isLoggedIn() && isPhoneVerified()) showHome();
        else if (isLoggedIn())                  showPhoneVerify();
        else                                     showAuth();
    }

    // ── Auth (name + email — identity, not abuse gate) ──────────────────────

    private void bindAuthViews() {
        authLayout   = findViewById(R.id.authLayout);
        etName       = findViewById(R.id.etName);
        etEmail      = findViewById(R.id.etEmail);
        btnAuth      = findViewById(R.id.btnAuth);
        tvAuthToggle = findViewById(R.id.tvAuthToggle);
        tvAuthMode   = findViewById(R.id.tvAuthMode);

        btnAuth.setOnClickListener(v -> handleAuth());

        tvAuthToggle.setOnClickListener(v -> {
            isLoginMode = !isLoginMode;
            etName.setVisibility(isLoginMode ? View.GONE : View.VISIBLE);
            tvAuthMode.setText(isLoginMode ? "ورود" : "ثبت‌نام");
            btnAuth.setText(isLoginMode ? "ورود" : "ادامه");
            tvAuthToggle.setText(isLoginMode ? "حساب ندارید؟ ثبت‌نام" : "قبلاً ثبت‌نام کردید؟ ورود");
        });
    }

    private void handleAuth() {
        String email = etEmail.getText().toString().trim();
        String name  = isLoginMode ? prefs.getString(PREF_NAME, "")
                                   : etName.getText().toString().trim();

        if (!email.contains("@")) {
            etEmail.setError("ایمیل معتبر وارد کنید");
            return;
        }
        if (!isLoginMode && name.length() < 2) {
            etName.setError("نام را وارد کنید");
            return;
        }

        prefs.edit()
            .putString(PREF_EMAIL, email)
            .putString(PREF_NAME, name)
            .apply();

        // Returning user who already verified their phone before → skip straight to home
        if (isPhoneVerified()) showHome();
        else                   showPhoneVerify();
    }

    // ── Phone verification (THIS is the real free-credit gate) ──────────────
    // 7 free try-ons are tied to a verified phone number, checked against the
    // backend's phone registry — not to the email, which costs nothing to fake.

    private void bindPhoneViews() {
        phoneLayout  = findViewById(R.id.phoneLayout);
        etPhone      = findViewById(R.id.etPhone);
        etOtp        = findViewById(R.id.etOtp);
        btnSendOtp   = findViewById(R.id.btnSendOtp);
        btnVerifyOtp = findViewById(R.id.btnVerifyOtp);
        otpGroup     = findViewById(R.id.otpGroup);

        btnSendOtp.setOnClickListener(v -> sendOtp());
        btnVerifyOtp.setOnClickListener(v -> verifyOtp());
    }

    private void sendOtp() {
        String phone = etPhone.getText().toString().trim();
        if (phone.length() < 10) {
            etPhone.setError("شماره موبایل معتبر وارد کنید");
            return;
        }
        btnSendOtp.setEnabled(false);
        btnSendOtp.setText("در حال ارسال...");

        // Backend call: POST /auth/send-otp { phone, deviceId }
        // Server checks: has this phone OR this device already used free credits?
        ApiClient.sendOtp(phone, getDeviceId(), new ApiClient.Callback() {
            @Override public void onSuccess(String json) {
                runOnUiThread(() -> {
                    btnSendOtp.setEnabled(true);
                    btnSendOtp.setText("ارسال مجدد کد");
                    otpGroup.setVisibility(View.VISIBLE);
                    Toast.makeText(MainActivity.this, "کد تایید پیامک شد", Toast.LENGTH_SHORT).show();
                });
            }
            @Override public void onError(String message) {
                runOnUiThread(() -> {
                    btnSendOtp.setEnabled(true);
                    btnSendOtp.setText("ارسال کد تایید");
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void verifyOtp() {
        String phone = etPhone.getText().toString().trim();
        String otp   = etOtp.getText().toString().trim();
        if (otp.length() < 4) {
            etOtp.setError("کد را کامل وارد کنید");
            return;
        }
        btnVerifyOtp.setEnabled(false);

        // Backend call: POST /auth/verify-otp { phone, otp, deviceId, email }
        // Server response tells us the REAL credit count — it owns the
        // phone+device → credits mapping, not the client.
        ApiClient.verifyOtp(phone, otp, getDeviceId(), prefs.getString(PREF_EMAIL, ""),
            new ApiClient.Callback() {
                @Override public void onSuccess(String json) {
                    runOnUiThread(() -> {
                        int serverCredits = ApiClient.parseCredits(json); // 7 if phone is new, less if reused
                        String serverPlan = ApiClient.parsePlan(json);
                        prefs.edit()
                            .putString(PREF_PHONE, phone)
                            .putInt(PREF_CREDITS, serverCredits)
                            .putString(PREF_PLAN, serverPlan)
                            .apply();
                        showHome();
                    });
                }
                @Override public void onError(String message) {
                    runOnUiThread(() -> {
                        btnVerifyOtp.setEnabled(true);
                        etOtp.setError("کد اشتباه است");
                        Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                    });
                }
            });
    }

    private void showPhoneVerify() {
        authLayout.setVisibility(View.GONE);
        homeLayout.setVisibility(View.GONE);
        phoneLayout.setVisibility(View.VISIBLE);
    }

    // ── Home ──────────────────────────────────────────────────────────────

    private void bindHomeViews() {
        homeLayout   = findViewById(R.id.homeLayout);
        tvWelcome    = findViewById(R.id.tvWelcome);
        tvCredits    = findViewById(R.id.tvCredits);
        btnTryOn     = findViewById(R.id.btnTryOn);
        btnFloating  = findViewById(R.id.btnFloating);

        btnTryOn.setOnClickListener(v -> {
            if (!hasCredits()) {
                startActivity(new Intent(this, PaywallActivity.class));
                return;
            }
            startActivity(new Intent(this, TryOnActivity.class));
        });

        btnFloating.setOnClickListener(v -> launchFloatingBubble());
    }

    private void showHome() {
        authLayout.setVisibility(View.GONE);
        phoneLayout.setVisibility(View.GONE);
        homeLayout.setVisibility(View.VISIBLE);
        refreshHomeUI();
    }

    private void showAuth() {
        homeLayout.setVisibility(View.GONE);
        phoneLayout.setVisibility(View.GONE);
        authLayout.setVisibility(View.VISIBLE);
    }

    void refreshHomeUI() {
        String name    = prefs.getString(PREF_NAME, "کاربر");
        int    credits = prefs.getInt(PREF_CREDITS, 0);
        String plan    = prefs.getString(PREF_PLAN, null);

        tvWelcome.setText("سلام " + name + " 👋");

        if (plan != null)  tvCredits.setText("پلن فعال: " + planLabel(plan) + " ✅");
        else               tvCredits.setText(credits + " عکس رایگان باقیمانده");
    }

    private String planLabel(String plan) {
        if ("monthly".equals(plan)) return "اشتراک ماهانه فعال";
        return plan;
    }

    // ── Floating bubble ───────────────────────────────────────────────────

    private void launchFloatingBubble() {
        if (!Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, OVERLAY_PERM_REQ);
            Toast.makeText(this, "اجازه نمایش روی برنامه‌ها را بده، سپس دوباره بزن", Toast.LENGTH_LONG).show();
            return;
        }
        // Trigger the system "Start recording or casting?" dialog once.
        // After grant, ScreenCaptureService stays armed and the bubble appears.
        startActivity(new Intent(this, MediaProjectionPermissionActivity.class));
        moveTaskToBack(true);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == OVERLAY_PERM_REQ && Settings.canDrawOverlays(this)) {
            launchFloatingBubble();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (isLoggedIn() && isPhoneVerified()) refreshHomeUI();
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private boolean isLoggedIn() {
        return !TextUtils.isEmpty(prefs.getString(PREF_EMAIL, ""));
    }

    private boolean isPhoneVerified() {
        return !TextUtils.isEmpty(prefs.getString(PREF_PHONE, ""));
    }

    /**
     * Stable per-install identifier sent to the backend alongside the phone
     * number. Neither signal alone is bulletproof (phone numbers can be
     * bought, ANDROID_ID resets on factory reset) but together they make
     * the "10 emails = 70 free tries" trick costly enough to stop casual abuse.
     * The actual decision of how many free credits remain is made server-side.
     */
    private String getDeviceId() {
        return Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
    }

    private boolean hasCredits() {
        if ("monthly".equals(prefs.getString(PREF_PLAN, null))) return true;
        return prefs.getInt(PREF_CREDITS, 0) > 0;
    }
}
