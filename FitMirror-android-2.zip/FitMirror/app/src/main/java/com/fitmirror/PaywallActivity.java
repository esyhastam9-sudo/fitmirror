package com.fitmirror;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Single monthly subscription paywall.
 * Shown after the 7 free (phone-verified) try-ons are used up.
 */
public class PaywallActivity extends AppCompatActivity {

    private SharedPreferences prefs;
    private Button btnPay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paywall);

        prefs = getSharedPreferences("fitmirror", MODE_PRIVATE);

        btnPay  = findViewById(R.id.btnPay);
        Button btnBack = findViewById(R.id.btnBack);

        btnPay.setOnClickListener(v -> subscribe());
        btnBack.setOnClickListener(v -> finish());
    }

    private void subscribe() {
        String phone = prefs.getString(MainActivity.PREF_PHONE, "");
        btnPay.setEnabled(false);
        btnPay.setText("در حال پرداخت...");

        // TODO: integrate real billing (Google Play Billing / Stripe) before
        // calling subscribe — this MVP assumes payment already succeeded
        // and just registers the resulting subscription with the backend.
        ApiClient.subscribe(phone, "monthly", new ApiClient.Callback() {
            @Override public void onSuccess(String json) {
                runOnUiThread(() -> {
                    prefs.edit().putString(MainActivity.PREF_PLAN, "monthly").apply();
                    Toast.makeText(PaywallActivity.this, "پرداخت موفق! اشتراک فعال شد ✅", Toast.LENGTH_SHORT).show();
                    finish();
                });
            }
            @Override public void onError(String message) {
                runOnUiThread(() -> {
                    btnPay.setEnabled(true);
                    btnPay.setText("پرداخت و فعال‌سازی");
                    Toast.makeText(PaywallActivity.this, message, Toast.LENGTH_LONG).show();
                });
            }
        });
    }
}
