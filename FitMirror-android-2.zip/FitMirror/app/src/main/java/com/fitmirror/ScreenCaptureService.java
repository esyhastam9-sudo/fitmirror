package com.fitmirror;

import android.app.*;
import android.content.Intent;
import android.graphics.*;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.net.Uri;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import androidx.core.app.NotificationCompat;

import java.io.*;
import java.nio.ByteBuffer;

/**
 * ScreenCaptureService
 * ────────────────────
 * Holds a long-lived MediaProjection (granted once via the system dialog),
 * and on each "CAPTURE" command grabs exactly one frame of whatever is
 * currently on screen — gallery, Telegram, Instagram, a browser, anything —
 * then hands the bitmap to TryOnActivity as the clothing photo.
 *
 * This mirrors how Screen Translate works: permission once, repeated
 * captures afterward without re-prompting, until the bubble is closed.
 */
public class ScreenCaptureService extends Service {

    public static final String ACTION_START   = "START";
    public static final String ACTION_CAPTURE = "CAPTURE";
    public static final String ACTION_STOP    = "STOP";

    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_RESULT_DATA = "result_data";

    private static final String CHANNEL_ID = "fitmirror_capture";
    private static final int    NOTIF_ID   = 2;

    private MediaProjection projection;
    private ImageReader     imageReader;
    private VirtualDisplay  virtualDisplay;
    private int screenWidth, screenHeight, screenDensity;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();

        DisplayMetrics dm = getResources().getDisplayMetrics();
        screenWidth   = dm.widthPixels;
        screenHeight  = dm.heightPixels;
        screenDensity = dm.densityDpi;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();

        if (ACTION_START.equals(action)) {
            startForeground(NOTIF_ID, buildNotification());
            int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED);
            Intent resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA);

            MediaProjectionManager mgr =
                    (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = mgr.getMediaProjection(resultCode, resultData);
            setupVirtualDisplay();

        } else if (ACTION_CAPTURE.equals(action)) {
            captureFrame();

        } else if (ACTION_STOP.equals(action)) {
            teardown();
            stopSelf();
        }
        return START_STICKY;
    }

    // ── Virtual display plumbing ─────────────────────────────────────────

    private void setupVirtualDisplay() {
        imageReader = ImageReader.newInstance(
                screenWidth, screenHeight, PixelFormat.RGBA_8888, 2);

        virtualDisplay = projection.createVirtualDisplay(
                "FitMirrorCapture",
                screenWidth, screenHeight, screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(), null, null
        );
    }

    /**
     * Grabs the latest available frame, converts to a Bitmap,
     * saves to cache, then opens TryOnActivity with the file URI.
     */
    private void captureFrame() {
        if (imageReader == null) return;

        // Give the virtual display a brief moment to render a fresh frame
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            android.media.Image image = imageReader.acquireLatestImage();
            if (image == null) {
                Toast_safe("نتونستم صفحه رو بگیرم، دوباره امتحان کن");
                return;
            }

            Bitmap bitmap = imageToBitmap(image);
            image.close();

            if (bitmap != null) {
                Uri uri = saveBitmapToCache(bitmap);
                if (uri != null) {
                    Intent tryOn = new Intent(this, TryOnActivity.class);
                    tryOn.putExtra(TryOnActivity.EXTRA_CLOTH_URI, uri.toString());
                    tryOn.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(tryOn);
                }
            }
        }, 100);
    }

    private Bitmap imageToBitmap(android.media.Image image) {
        try {
            android.media.Image.Plane[] planes = image.getPlanes();
            ByteBuffer buffer = planes[0].getBuffer();
            int pixelStride = planes[0].getPixelStride();
            int rowStride   = planes[0].getRowStride();
            int rowPadding  = rowStride - pixelStride * screenWidth;

            Bitmap bitmap = Bitmap.createBitmap(
                    screenWidth + rowPadding / pixelStride,
                    screenHeight, Bitmap.Config.ARGB_8888);
            bitmap.copyPixelsFromBuffer(buffer);

            // Crop padding off
            return Bitmap.createBitmap(bitmap, 0, 0, screenWidth, screenHeight);
        } catch (Exception e) {
            return null;
        }
    }

    private Uri saveBitmapToCache(Bitmap bitmap) {
        try {
            File dir = new File(getCacheDir(), "captures");
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, "cloth_" + System.currentTimeMillis() + ".png");

            try (FileOutputStream fos = new FileOutputStream(file)) {
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            }

            return androidx.core.content.FileProvider.getUriForFile(
                    this, getPackageName() + ".fileprovider", file);
        } catch (IOException e) {
            return null;
        }
    }

    private void Toast_safe(String msg) {
        new Handler(Looper.getMainLooper()).post(() ->
                android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_SHORT).show());
    }

    // ── Cleanup ───────────────────────────────────────────────────────────

    private void teardown() {
        if (virtualDisplay != null) virtualDisplay.release();
        if (imageReader != null)    imageReader.close();
        if (projection != null)     projection.stop();
        virtualDisplay = null;
        imageReader = null;
        projection = null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        teardown();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    // ── Notification ─────────────────────────────────────────────────────

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "FitMirror Capture", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private Notification buildNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("FitMirror در حال ضبط صفحه")
                .setContentText("برای پروو لباس آماده‌ست")
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setOngoing(true)
                .build();
    }
}
