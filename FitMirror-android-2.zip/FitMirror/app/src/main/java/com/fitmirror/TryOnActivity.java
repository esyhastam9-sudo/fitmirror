package com.fitmirror;

import android.content.SharedPreferences;
import android.graphics.*;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import org.json.*;

import java.io.*;
import java.net.*;

/**
 * TryOnActivity
 * ─────────────
 * Two-image screen: user's selfie (stored in prefs as URI) + clothing image.
 * Sends both to Claude Vision API → shows analysis in Persian.
 *
 * Entry points:
 *   • From HomeScreen "پروو کن" button → prompts for selfie first if not saved
 *   • From FloatingBubbleService via ImagePickerTrampolineActivity →
 *       clothing URI arrives via EXTRA_CLOTH_URI
 */
public class TryOnActivity extends AppCompatActivity {

    public static final String EXTRA_CLOTH_URI = "cloth_uri";

    private static final String CLAUDE_ENDPOINT =
            "https://api.anthropic.com/v1/messages";
    // ⚠️  Replace with your key or inject via BuildConfig
    private static final String API_KEY = "YOUR_ANTHROPIC_API_KEY";

    private SharedPreferences prefs;

    private ImageView ivSelfie, ivCloth;
    private Button    btnPickSelfie, btnPickCloth, btnTryOn;
    private TextView  tvResult, tvCredits;
    private ProgressBar progressBar;
    private CardView  resultCard;

    private Uri selfieUri;
    private Uri clothUri;

    private static final int PICK_SELFIE = 301;
    private static final int PICK_CLOTH  = 302;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_try_on);

        prefs = getSharedPreferences("fitmirror", MODE_PRIVATE);

        bindViews();
        refreshCreditsUI();

        // Clothing may arrive directly from bubble
        String clothUriStr = getIntent().getStringExtra(EXTRA_CLOTH_URI);
        if (clothUriStr != null) {
            clothUri = Uri.parse(clothUriStr);
            ivCloth.setImageURI(clothUri);
            btnPickCloth.setText("عوض کردن لباس");
        }

        // Restore previously saved selfie URI
        String savedSelfie = prefs.getString("selfie_uri", null);
        if (savedSelfie != null) {
            selfieUri = Uri.parse(savedSelfie);
            ivSelfie.setImageURI(selfieUri);
            btnPickSelfie.setText("عوض کردن عکس من");
        }
    }

    private void bindViews() {
        ivSelfie      = findViewById(R.id.ivSelfie);
        ivCloth       = findViewById(R.id.ivCloth);
        btnPickSelfie = findViewById(R.id.btnPickSelfie);
        btnPickCloth  = findViewById(R.id.btnPickCloth);
        btnTryOn      = findViewById(R.id.btnTryOn);
        tvResult      = findViewById(R.id.tvResult);
        tvCredits     = findViewById(R.id.tvCredits);
        progressBar   = findViewById(R.id.progressBar);
        resultCard    = findViewById(R.id.resultCard);

        btnPickSelfie.setOnClickListener(v -> pickImage(PICK_SELFIE));
        btnPickCloth.setOnClickListener(v -> pickImage(PICK_CLOTH));
        btnTryOn.setOnClickListener(v -> runTryOn());
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
    }

    private void pickImage(int requestCode) {
        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
        pick.setType("image/*");
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(pick, "انتخاب تصویر"), requestCode);
    }

    @Override
    protected void onActivityResult(int req, int res, android.content.Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null) return;

        Uri uri = data.getData();
        if (req == PICK_SELFIE) {
            selfieUri = uri;
            ivSelfie.setImageURI(selfieUri);
            btnPickSelfie.setText("عوض کردن عکس من");
            // Persist so bubble flow doesn't need to re-pick
            prefs.edit().putString("selfie_uri", selfieUri.toString()).apply();
        } else if (req == PICK_CLOTH) {
            clothUri = uri;
            ivCloth.setImageURI(clothUri);
            btnPickCloth.setText("عوض کردن لباس");
        }
    }

    // ── Try-On ────────────────────────────────────────────────────────────

    private void runTryOn() {
        if (selfieUri == null) {
            Toast.makeText(this, "ابتدا عکس خودت را آپلود کن", Toast.LENGTH_SHORT).show();
            return;
        }
        if (clothUri == null) {
            Toast.makeText(this, "لباسی انتخاب نشده", Toast.LENGTH_SHORT).show();
            return;
        }

        String plan    = prefs.getString(MainActivity.PREF_PLAN, null);
        String phone   = prefs.getString(MainActivity.PREF_PHONE, "");
        int    credits = prefs.getInt(MainActivity.PREF_CREDITS, 0);
        boolean isMonthly = "monthly".equals(plan);
        if (!isMonthly && credits <= 0) {
            startActivity(new android.content.Intent(this, PaywallActivity.class));
            return;
        }

        setLoading(true);
        resultCard.setVisibility(View.GONE);

        new Thread(() -> {
            try {
                String selfieB64 = uriToBase64(selfieUri);
                String clothB64  = uriToBase64(clothUri);
                String response  = callClaude(selfieB64, clothB64);

                runOnUiThread(() -> {
                    setLoading(false);
                    tvResult.setText(response);
                    resultCard.setVisibility(View.VISIBLE);

                    // Credit is decremented server-side — the device/prefs value
                    // is only a display cache, never the source of truth.
                    if (!isMonthly) {
                        ApiClient.consumeCredit(phone, new ApiClient.Callback() {
                            @Override public void onSuccess(String json) {
                                int serverCredits = ApiClient.parseCredits(json);
                                prefs.edit().putInt(MainActivity.PREF_CREDITS, serverCredits).apply();
                                refreshCreditsUI();
                            }
                            @Override public void onError(String message) {
                                // Network hiccup: keep optimistic local count so UX doesn't break,
                                // server reconciles credits on next verify-otp / app open.
                                prefs.edit().putInt(MainActivity.PREF_CREDITS, Math.max(0, credits - 1)).apply();
                                refreshCreditsUI();
                            }
                        });
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    setLoading(false);
                    Toast.makeText(this, "خطا: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    private String callClaude(String selfieB64, String clothB64) throws Exception {
        URL url = new URL(CLAUDE_ENDPOINT);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("x-api-key", API_KEY);
        conn.setRequestProperty("anthropic-version", "2023-06-01");
        conn.setDoOutput(true);
        conn.setConnectTimeout(30_000);
        conn.setReadTimeout(60_000);

        JSONObject body = new JSONObject();
        body.put("model", "claude-sonnet-4-6");
        body.put("max_tokens", 1000);
        body.put("system",
            "تو یک دستیار مد هوشمند هستی. دو تصویر دریافت می‌کنی: " +
            "اول عکس شخص، دوم لباس. " +
            "تحلیل کن این لباس چطور به این شخص می‌آید: " +
            "اندازه، هماهنگی رنگ، استایل، و توصیه نهایی. " +
            "کوتاه و مفید بنویس. فقط فارسی."
        );

        JSONArray messages = new JSONArray();
        JSONObject userMsg = new JSONObject();
        userMsg.put("role", "user");

        JSONArray content = new JSONArray();

        // Selfie image
        content.put(imageBlock(selfieB64, "image/jpeg"));

        // Clothing image
        content.put(imageBlock(clothB64, "image/jpeg"));

        // Text prompt
        JSONObject textBlock = new JSONObject();
        textBlock.put("type", "text");
        textBlock.put("text", "این لباس را روی این شخص تحلیل کن. آیا مناسب است؟ چه توصیه‌ای داری؟");
        content.put(textBlock);

        userMsg.put("content", content);
        messages.put(userMsg);
        body.put("messages", messages);

        // Write
        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.toString().getBytes("UTF-8"));
        }

        // Read
        int status = conn.getResponseCode();
        InputStream is = status >= 400 ? conn.getErrorStream() : conn.getInputStream();
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        }

        JSONObject resp = new JSONObject(sb.toString());
        if (status >= 400) {
            throw new Exception(resp.optString("error", "خطای سرور"));
        }

        JSONArray contentArr = resp.getJSONArray("content");
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < contentArr.length(); i++) {
            JSONObject block = contentArr.getJSONObject(i);
            if ("text".equals(block.optString("type"))) {
                result.append(block.getString("text"));
            }
        }
        return result.toString();
    }

    private JSONObject imageBlock(String base64, String mediaType) throws JSONException {
        JSONObject source = new JSONObject();
        source.put("type", "base64");
        source.put("media_type", mediaType);
        source.put("data", base64);

        JSONObject block = new JSONObject();
        block.put("type", "image");
        block.put("source", source);
        return block;
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    private String uriToBase64(Uri uri) throws Exception {
        InputStream is = getContentResolver().openInputStream(uri);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) != -1) bos.write(buf, 0, n);
        is.close();
        return Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
    }

    private void setLoading(boolean loading) {
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        btnTryOn.setEnabled(!loading);
        btnTryOn.setText(loading ? "در حال پروو..." : "🪄  پروو کن!");
    }

    private void refreshCreditsUI() {
        String plan    = prefs.getString(MainActivity.PREF_PLAN, null);
        int    credits = prefs.getInt(MainActivity.PREF_CREDITS, 0);
        if ("monthly".equals(plan)) tvCredits.setText("اشتراک ماهانه فعال ✅");
        else                        tvCredits.setText(credits + " عکس باقیمانده");
    }
}
